const searchHistory = [];
const searchInput = document.getElementById('searchText');
const searchHistoryContainer = document.getElementById('searchHistory');
const sendButton = document.getElementById('send');

sendButton.addEventListener('click', sendSearch);


function sendSearch(event) {
  const searchTerm = searchInput.value;
  const encodedSearchTerm = encodeURIComponent(searchTerm);

  fetch('/api/search/school/' + encodedSearchTerm, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    },
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Problema con la respuesta del servidor');
    }
    return response.json();
  })
  .then(data => {
    console.log(data);
    const nuevoParrafo = document.createElement('p');
    // Asignar contenido con varios atributos
    nuevoParrafo.textContent = `Prepa ${data.Preparatorias}, `;
    
    if (data.moodle === null) {
      const textoNoDisponible = document.createTextNode('No disponible, ');
      nuevoParrafo.appendChild(textoNoDisponible);
    } else {
      const enlaceMoodle = document.createElement('a');
      enlaceMoodle.href = data.Moodle;
      enlaceMoodle.textContent = ' Moodle, ';
      nuevoParrafo.appendChild(enlaceMoodle);
    }
    
    const textoSIIAU = document.createElement('a');
    textoSIIAU.href = data.Siiau;
    textoSIIAU.textContent = ' SIIAU, ';

    nuevoParrafo.appendChild(textoSIIAU);

    const textoTAES = document.createElement('a');
    textoTAES.href = data.Taes;
    textoTAES.textContent = ' TAES, ';
    nuevoParrafo.appendChild(textoTAES);

    const textoPlandeestudios = document.createElement('a');
    textoPlandeestudios.href = data.Plandeestudios;
    textoPlandeestudios.textContent = ' Plan de estudios, ';
    nuevoParrafo.appendChild(textoPlandeestudios);

    const textoBachilleratotecnico = document.createElement('a');
    textoBachilleratotecnico.href = data.Bachilleratotecnico;
    textoBachilleratotecnico.textContent = ' Bachillerato tecnico, ';
    nuevoParrafo.appendChild(textoBachilleratotecnico);

    const textoBachilleratogeneral = document.createElement('a');
    textoBachilleratogeneral.href = data.Bachilleratogeneral; 
    textoBachilleratogeneral.textContent = ' Bachillerato general, ';
    nuevoParrafo.appendChild(textoBachilleratogeneral);

    const textoServiciosocial = document.createElement('a');
    textoServiciosocial.href = data.Serviciosocial;
    textoServiciosocial.textContent = ' Servicio social, ';
    nuevoParrafo.appendChild(textoServiciosocial);

    // Agregar el párrafo al contenedor
    searchHistoryContainer.appendChild(nuevoParrafo);
  })  
  .catch(error => {
    // Manejar errores en la solicitud o en la respuesta
    console.error('Error:', error);
  });
  event.preventDefault();
}



/*// Function to add a new search term to the history and display it
function addSearchToHistory(searchTerm) {
  // Add the search term to the history array
  searchHistory.push(searchTerm);

  // Limit the history to a maximum number of items (optional)
  if (searchHistory.length > 10) {
    searchHistory.shift(); // Remove the oldest item if the history is too long
  }

  // Create a new list item element for the search term
  const newListItem = document.createElement('li');
  newListItem.textContent = searchTerm;

  // Add the list item to the search history container
  searchHistoryContainer.appendChild(newListItem);
}

// Function to send the search term and update the history
function sendSearch(event) {
  const searchTerm = searchInput.value.trim();

  // Check if the search term is not empty and not already in the history
  if (searchTerm && !searchHistory.includes(searchTerm)) {
    // Add the search term to the history
    addSearchToHistory(searchTerm);

    // Clear the search input field
    searchInput.value = '';
  }

  // Prevent default form submission behavior (e.g., page refresh)
  event.preventDefault();
}

// Event listener for the send button click and Enter key press
sendButton.addEventListener('click', sendSearch);
searchInput.addEventListener('keypress', function(event) {
  if (event.key === 'Enter') {
    sendSearch(event);
  }
});


function addSearchToHistory(searchTerm) {
  searchHistory.push(searchTerm);


  if (searchHistory.length > 30) {
    searchHistory.shift(); 
  }


  const newListItem = document.createElement('li');
  newListItem.textContent = searchTerm;


  searchHistoryContainer.appendChild(newListItem);
}


function sendSearch() {
  const searchTerm = searchInput.value.trim();


  if (searchTerm && !searchHistory.includes(searchTerm)) {
    addSearchToHistory(searchTerm);

    searchInput.value = '';
  }
}

sendButton.addEventListener('click', sendSearch);*/